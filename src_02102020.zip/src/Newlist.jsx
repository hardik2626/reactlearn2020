import React from 'react';


function Newlist (){
    return ( 
            <React.Fragment>
            <ol>
                <li>Hardik Devani</li>
                <li>Hardik </li>
                <li>Hardik Wordpress</li>
                <li>Hardik Patel</li>
            </ol>
            </React.Fragment>
    )
}

export default Newlist;