import React from 'react';


function Para (){
    return <p> My Name is Aureate paragraph </p>
    
}

export default Para;