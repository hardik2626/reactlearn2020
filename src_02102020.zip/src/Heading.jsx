import React from 'react';


function Heading (){
    return <h1> My Name is Aureate </h1>
    
}

export default Heading;