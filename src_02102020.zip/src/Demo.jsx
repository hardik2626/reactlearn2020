import React from 'react';
import ReactDOM from 'react-dom';

function Demo() {
    return(
        <label style={{color:"green"}}>Good Morning</label>
        //greeting = 'Good Morning';
        //cssStyle.color = "green";
    )
}

export default Demo